// lib/views/admin/user_management_view.dart (Contenido COMPLETO Y CORREGIDO)

import 'package:flutter/material.dart';
import '/models/user_model.dart';
import '/services/user_service.dart';

class UserManagementView extends StatefulWidget {
  const UserManagementView({super.key});

  @override
  State<UserManagementView> createState() => _UserManagementViewState();
}

class _UserManagementViewState extends State<UserManagementView> {
  final UserService _userService = UserService();
  Future<List<UserModel>>? _usersFuture;

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  // Carga la lista de usuarios
  void _loadUsers() {
    setState(() {
      _usersFuture = _userService.getUsers();
    });
  }

  // Muestra un SnackBar con un mensaje de feedback
  void _showSnackBar(String message, {bool isError = false}) {
    final Color successColor = Theme.of(context).colorScheme.primary;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : successColor,
      ),
    );
  }

  // --- Funciones de CRUD (Interface) ---

  // Diálogo para Crear o Editar
  Future<void> _showUserForm({UserModel? userToEdit}) async {
    // Usamos el `!` para userToEdit en caso de edición, ya que sabemos que no es null
    final TextEditingController usernameController = TextEditingController(
      text: userToEdit?.username,
    );
    final TextEditingController passwordController = TextEditingController();
    String? selectedRole = userToEdit?.role ?? 'user';
    final isEditing = userToEdit != null;
    final usernameEnabled = true; // Permite la edición del username

    // Estado local para la visibilidad de la contraseña
    bool isPasswordVisible = false;

    await showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        // Usamos StatefulBuilder para que el Dropdown y el TOGGLE puedan actualizar su estado
        return StatefulBuilder(
          builder: (context, setStateSB) {
            return AlertDialog(
              title: Text(isEditing ? 'Editar Usuario' : 'Nuevo Usuario'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    // Campo Username
                    TextField(
                      controller: usernameController,
                      decoration: const InputDecoration(
                        labelText: 'Nombre de Usuario',
                      ),
                      enabled: usernameEnabled,
                    ),
                    // Campo Contraseña con TOGGLE de visibilidad
                    TextField(
                      controller: passwordController,
                      // CONTROLADO POR EL ESTADO LOCAL
                      obscureText: !isPasswordVisible,
                      decoration: InputDecoration(
                        labelText: isEditing
                            ? 'Nueva Contraseña (Mínimo 6 chars, dejar vacío para mantener)'
                            : 'Contraseña (Mínimo 6 caracteres)',
                        // Botón de visibilidad
                        suffixIcon: IconButton(
                          icon: Icon(
                            isPasswordVisible
                                ? Icons.visibility
                                : Icons.visibility_off,
                          ),
                          onPressed: () {
                            // Actualiza el estado del diálogo para cambiar el icono y obscureText
                            setStateSB(() {
                              isPasswordVisible = !isPasswordVisible;
                            });
                          },
                        ),
                      ),
                    ),
                    // Selector de Rol
                    DropdownButtonFormField<String>(
                      value: selectedRole,
                      decoration: const InputDecoration(labelText: 'Rol'),
                      items: const <String>['root', 'admin', 'user']
                          .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          })
                          .toList(),
                      onChanged: (String? newValue) {
                        setStateSB(() {
                          selectedRole = newValue;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('Cancelar'),
                  onPressed: () {
                    Navigator.of(dialogContext).pop();
                  },
                ),
                ElevatedButton(
                  child: Text(isEditing ? 'Guardar Cambios' : 'Crear Usuario'),
                  onPressed: () async {
                    try {
                      if (isEditing) {
                        // --- UPDATE ---
                        final Map<String, dynamic> updateData = {};

                        // 1. CAPTURAR Y VALIDAR NEW_USERNAME (CORRECCIÓN CLAVE)
                        if (usernameController.text.isNotEmpty &&
                            userToEdit.username != usernameController.text) {
                          // El backend FastAPI espera 'new_username'
                          updateData['new_username'] = usernameController.text;
                        }

                        // 2. VALIDAR Y CAPTURAR PASSWORD
                        if (passwordController.text.isNotEmpty) {
                          if (passwordController.text.length < 6) {
                            throw Exception(
                              'La nueva contraseña debe tener al menos 6 caracteres.',
                            );
                          }
                          updateData['password'] = passwordController.text;
                        }

                        // 3. CAPTURAR ROL
                        if (userToEdit.role != selectedRole) {
                          updateData['role'] = selectedRole;
                        }

                        // 4. EJECUTAR ACTUALIZACIÓN
                        if (updateData.isNotEmpty) {
                          await _userService.updateUser(
                            userToEdit
                                .username, // Usa el username ORIGINAL para la URL
                            updateData,
                          );

                          // Determina el nombre final para el mensaje de éxito
                          final String finalUsername =
                              updateData.containsKey('new_username')
                              ? updateData['new_username']
                              : userToEdit.username;

                          _showSnackBar('Usuario $finalUsername actualizado.');
                        } else {
                          _showSnackBar(
                            'No se realizaron cambios.',
                            isError: true,
                          );
                        }
                      } else {
                        // --- CREATE ---

                        // VALIDACIÓN SIMPLE EN CREACIÓN
                        if (usernameController.text.isEmpty ||
                            passwordController.text.isEmpty) {
                          throw Exception(
                            'Nombre de usuario y contraseña son requeridos.',
                          );
                        }
                        if (passwordController.text.length < 6) {
                          throw Exception(
                            'La contraseña debe tener al menos 6 caracteres.',
                          );
                        }

                        await _userService.createUser(
                          UserModel(
                            username: usernameController.text,
                            password: passwordController.text,
                            role: selectedRole!,
                          ),
                        );
                        _showSnackBar(
                          'Usuario ${usernameController.text} creado con éxito.',
                        );
                      }

                      _loadUsers();
                      if (mounted) Navigator.of(dialogContext).pop();
                    } catch (e) {
                      _showSnackBar(
                        e.toString().replaceFirst('Exception: ', ''),
                        isError: true,
                      );
                    }
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  // Diálogo para Eliminar (Se mantiene sin cambios)
  Future<void> _deleteUser(UserModel user) async {
    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar Eliminación'),
        content: Text('¿Está seguro de que desea eliminar a ${user.username}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Eliminar', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await _userService.deleteUser(user.username);
        _showSnackBar('Usuario ${user.username} eliminado correctamente.');
        _loadUsers();
      } catch (e) {
        _showSnackBar(
          e.toString().replaceFirst('Exception: ', ''),
          isError: true,
        );
      }
    }
  }

  // --- Renderizado de la lista (Se mantiene sin cambios) ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestión de Usuarios'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: FutureBuilder<List<UserModel>>(
        future: _usersFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  'Error al cargar usuarios: ${snapshot.error.toString().replaceFirst('Exception: ', '')}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            );
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No hay usuarios registrados.'));
          }

          final users = snapshot.data!;
          return ListView.builder(
            itemCount: users.length,
            itemBuilder: (context, index) {
              final user = users[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Theme.of(context).colorScheme.secondary,
                    foregroundColor: Colors.white,
                    child: Text(user.role[0].toUpperCase()),
                  ),
                  title: Text(
                    user.username,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('Rol: ${user.role} (ID: ${user.id ?? 'N/A'})'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Botón Editar
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _showUserForm(userToEdit: user),
                      ),
                      // Botón Eliminar
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: user.role == 'root'
                            ? null
                            : () => _deleteUser(user),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      // Botón flotante para crear nuevo usuario
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showUserForm(),
        child: const Icon(Icons.person_add),
      ),
    );
  }
}
