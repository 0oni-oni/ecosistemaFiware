// lib/views/devices/device_list_view.dart (Versión Final y Dinámica)

import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // NECESARIO para usar FiwareService y Provider

// Importaciones necesarias:
import '/models/entity_model.dart';
import '/services/fiware_service.dart';
import 'historic_view.dart'; // Importamos la vista de historial directa// Asumo que usas CustomSnackBar

class DeviceListView extends StatefulWidget {
  const DeviceListView({super.key});

  @override
  State<DeviceListView> createState() => _DeviceListViewState();
}

class _DeviceListViewState extends State<DeviceListView> {
  // Ya no usamos _fiwareService como variable de estado si usamos Provider
  late Future<List<EntityModel>> _entitiesFuture;

  @override
  void initState() {
    super.initState();
    _loadEntities();
  }

  void _loadEntities() {
    // Usar Provider para acceder al servicio de Fiware
    final fiwareService = Provider.of<FiwareService>(context, listen: false);
    setState(() {
      _entitiesFuture = fiwareService.getEntities();
    });
  }

  // Función auxiliar para mostrar mensajes (usando CustomSnackBar si existe, si no usa SnackBar normal)
  void _showSnackBar(String message, {bool isError = false}) {
    // Si tienes el widget CustomSnackBar:
    // CustomSnackBar.show(context, message, isError: isError);

    // Si no usas CustomSnackBar y quieres mantener el código simple:
    final Color successColor = Theme.of(context).colorScheme.primary;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : successColor,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  // --- NUEVA LÓGICA DE VISUALIZACIÓN DE ATRIBUTOS ---
  // Reemplaza la antigua _getPrimaryAttribute. Ahora usa el EntityModel limpio.
  String _formatAllAttributes(EntityModel entity) {
    // Utilizamos el método del modelo para encontrar el atributo principal (ej: 'humedad')
    final mainAttr = entity.getMainAttribute();
    if (mainAttr == null) {
      return 'Tipo: ${entity.type}';
    }

    // Muestra el nombre del atributo en mayúsculas y su valor
    return 'Último valor: ${mainAttr.key.toUpperCase()}: ${mainAttr.value.toString()} | Tipo: ${entity.type}';
  }

  // --- LÓGICA DE NAVEGACIÓN DIRECTA ---
  // Reemplaza la lógica de navegación a rutas nombradas.
  void _navigateToHistoric(EntityModel entity) {
    // CLAVE: Navegamos usando MaterialPageRoute para pasar el objeto completo
    Navigator.of(context)
        .push(
          MaterialPageRoute(
            builder: (context) =>
                HistoricView(entity: entity), // Pasamos la entidad
          ),
        )
        .then((_) {
          _loadEntities();
        });
  }

  // --- LÓGICA DE ELIMINACIÓN ---
  // Aseguramos que la eliminación use el FiwareService si está en Provider
  Future<void> _confirmAndDeleteDevice(EntityModel entity) async {
    final fiwareService = Provider.of<FiwareService>(context, listen: false);
    // Extraer el ID del dispositivo (Ej: "Sensor:temp001" -> "temp001")
    final String deviceId = entity.id.split(':').last;

    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar Eliminación'),
        content: Text(
          '¿Está seguro de que desea eliminar el dispositivo "$deviceId" y toda su configuración?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Eliminar', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Eliminando dispositivo...'),
            duration: Duration(seconds: 1),
          ),
        );

        // Usar la función de eliminación del servicio (asumo que es deleteDevice)
        await fiwareService.deleteDevice(deviceId);

        _showSnackBar(
          'Dispositivo "$deviceId" y su configuración eliminados.',
          isError: false,
        );
        _loadEntities();
      } catch (e) {
        _showSnackBar(
          e.toString().replaceFirst('Exception: ', ''),
          isError: true,
        );
      }
    }
  }

  // --- WIDGET BUILD ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Entidades FIWARE'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadEntities),
        ],
      ),
      body: FutureBuilder<List<EntityModel>>(
        future: _entitiesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  'Error al cargar entidades: ${snapshot.error.toString()}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            );
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text(
                'No se encontraron entidades FIWARE. ¡Añade una!',
                textAlign: TextAlign.center,
              ),
            );
          }

          final entities = snapshot.data!;
          return ListView.builder(
            itemCount: entities.length,
            itemBuilder: (context, index) {
              final entity = entities[index];
              // Usamos la nueva función dinámica para el subtítulo
              final primaryAttrText = _formatAllAttributes(entity);

              // Usamos el EntityModel limpio para saber si hay historial
              final mainAttrEntry = entity.getMainAttribute();

              return Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: ListTile(
                  leading: const Icon(Icons.devices_other),
                  title: Text(
                    entity.id,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(primaryAttrText), // Muestra el valor dinámico
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Botón de Historial (SOLO si hay atributo principal)
                      if (mainAttrEntry != null)
                        IconButton(
                          icon: const Icon(
                            Icons.history,
                            color: Colors.blueGrey,
                          ),
                          onPressed: () =>
                              _navigateToHistoric(entity), // Navegación directa
                        ),

                      // Botón de ELIMINACIÓN
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _confirmAndDeleteDevice(entity),
                      ),
                    ],
                  ),
                  onTap: () {
                    // Navegamos al historial si hay un atributo definido.
                    if (mainAttrEntry != null) {
                      _navigateToHistoric(entity);
                    }
                  },
                ),
              );
            },
          );
        },
      ),

      // Botón flotante para Registrar un nuevo Dispositivo
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.of(context).pushNamed('/devices/new');
          _loadEntities();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
