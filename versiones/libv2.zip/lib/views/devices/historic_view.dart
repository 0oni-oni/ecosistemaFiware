import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

// Importar modelos y servicios necesarios
import '../../models/historic_model.dart';
import '../../models/entity_model.dart'; // NECESARIO para obtener el atributo principal
import '../../services/fiware_service.dart';

class HistoricView extends StatefulWidget {
  // Ahora recibe el EntityModel completo para determinar el atributo
  final EntityModel entity;

  const HistoricView({Key? key, required this.entity}) : super(key: key);

  @override
  State<HistoricView> createState() => _HistoricViewState();
}

class _HistoricViewState extends State<HistoricView> {
  late Future<List<HistoricModel>> _historicDataFuture;
  late String
  _attributeName; // Variable para guardar el nombre del atributo (ej: 'humedad')
  late String _entityId;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  // --- LÓGICA CLAVE: Identificar el Atributo y Cargar Datos ---
  void _initializeData() {
    _entityId = widget.entity.id;

    // 1. Identificar el atributo principal usando el modelo de entidad
    final mainAttributeEntry = widget.entity.getMainAttribute();

    if (mainAttributeEntry == null) {
      // Manejo de error si no se encuentra un atributo de datos válido (solo TimeInstant)
      _attributeName = 'N/A';
      _historicDataFuture = Future.error(
        Exception(
          'No se encontró un atributo principal para consultar el historial (ej: temperature, humedad).',
        ),
      );
      return;
    }

    // 2. Obtener el nombre del atributo (ej: 'temperature', 'humedad')
    _attributeName = mainAttributeEntry.key;

    // 3. Cargar los datos históricos usando el nombre del atributo
    final fiwareService = Provider.of<FiwareService>(context, listen: false);

    _historicDataFuture = fiwareService.getHistoricData(
      entityId: _entityId,
      attributeName:
          _attributeName, // <-- CLAVE: Usamos el nombre del atributo dinámico
    );
  }

  // Permite refrescar la vista
  Future<void> _refreshData() async {
    setState(() {
      _initializeData();
    });
  }
  // -------------------------------------------------------------------

  // Widget para construir un elemento con estilo Card/ListTile
  Widget _buildHistoricItem(HistoricModel item) {
    // Usamos el getter formattedTime del HistoricModel si lo tiene, o formateamos aquí:
    final formattedTime = DateFormat(
      'dd/MM/yyyy HH:mm:ss',
    ).format(DateTime.parse(item.recvTime).toLocal());

    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: ListTile(
        leading: const Icon(Icons.trending_up, color: Colors.blueAccent),
        title: Text(
          // Muestra el nombre del atributo y su valor (ej: 'humedad: dies')
          'Valor de ${item.attributeName}: ${item.value}',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Text(
          'Tiempo de Recepción: $formattedTime',
          style: TextStyle(color: Colors.grey[600], fontSize: 12),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Historial: $_entityId ($_attributeName)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshData,
            tooltip: 'Actualizar Historial',
          ),
        ],
      ),
      body: FutureBuilder<List<HistoricModel>>(
        future: _historicDataFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            final errorMessage =
                snapshot.error.toString().contains('Exception:')
                ? snapshot.error.toString().split('Exception: ')[1]
                : snapshot.error.toString();
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  'Error al cargar historial: $errorMessage',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            );
          }

          final rows = snapshot.data ?? [];
          if (rows.isEmpty) {
            return const Center(
              child: Text('No hay datos históricos para este atributo.'),
            );
          }

          return ListView.builder(
            itemCount: rows.length,
            itemBuilder: (context, index) {
              return _buildHistoricItem(rows[index]);
            },
          );
        },
      ),
    );
  }
}
