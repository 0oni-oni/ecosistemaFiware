// lib/views/devices/device_form_view.dart

import 'package:flutter/material.dart';
import '/models/device_payload_model.dart';
import '/services/fiware_service.dart';

class DeviceFormView extends StatefulWidget {
  const DeviceFormView({super.key});

  @override
  State<DeviceFormView> createState() => _DeviceFormViewState();
}

class _DeviceFormViewState extends State<DeviceFormView> {
  final _formKey = GlobalKey<FormState>();

  // --- 1. Controladores ---
  final _deviceIdController = TextEditingController(text: 'temp004');
  final _attributeObjectIdController = TextEditingController(text: 't');
  final _attributeNameController = TextEditingController(text: 'temperature');
  // Inicializamos el controlador de tipo de atributo con un valor válido
  final _attributeTypeController = TextEditingController(text: 'Number');

  // --- 2. Listas para Selectores ---
  String? _selectedProtocol = 'HTTP';
  final List<String> _protocols = ['HTTP', 'MQTT'];

  String? _selectedEntityType = 'Sensor'; // Nuevo selector de tipo de entidad
  final List<String> _entityTypes = [
    'Sensor',
    'Actuator',
    'Door',
    'AccessPoint',
    'Device',
  ];

  final List<String> _attributeTypes = [
    'Number',
    'Text',
    'DateTime',
    'Boolean',
    'geo:json',
  ];

  bool _isLoading = false;

  // --- FUNCIÓN DE DIÁLOGO DE ÉXITO (Muestra las claves de conexión) ---
  void _showSuccessDialog(
    String deviceId,
    String apiKey,
    String transport,
    String entityType,
  ) {
    // 🚨 El Agente IoT JSON usa el puerto 7896 para data y la ruta /json
    final String iotDataUrl =
        'http://13.59.176.23:7896/json?k=$apiKey&i=$deviceId';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('✅ Registro Exitoso'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text(
                  'El dispositivo "$deviceId" (Tipo: $entityType) ha sido registrado.',
                ),
                const SizedBox(height: 15),
                const Text(
                  'Instrucciones de Conexión:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),

                // Muestra la clave de conexión (K) y el ID (I)
                ListTile(
                  title: const Text('Device ID (i):'),
                  subtitle: Text(deviceId),
                ),
                ListTile(
                  title: const Text('Service API Key (k):'),
                  subtitle: Text(apiKey),
                ),

                const SizedBox(height: 10),
                Text(
                  'URL de Envío ($transport):',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                // Instrucción de la URL que debe programarse en la ESP32
                SelectableText(
                  iotDataUrl,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cerrar'),
              onPressed: () {
                Navigator.of(context).pop(); // Cierra el diálogo
                Navigator.pop(context, true); // Regresa a la vista anterior
              },
            ),
          ],
        );
      },
    );
  }

  // --- FUNCIÓN PRINCIPAL DE REGISTRO ---
  Future<void> _registerDevice() async {
    if (!_formKey.currentState!.validate() ||
        _selectedProtocol == null ||
        _selectedEntityType == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error: Verifique todos los campos.'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final String finalDeviceId = _deviceIdController.text.trim();
    final String finalEntityType = _selectedEntityType!;

    // 🚨 Autogeneramos el Entity Name: Tipo:ID
    final String generatedEntityName = '$finalEntityType:$finalDeviceId';
    // 🚨 Usamos la API Key por defecto de tu servicio
    const String apiKey = '1234';

    final payload = DevicePayloadModel(
      deviceId: finalDeviceId,
      entityName: generatedEntityName, // <-- Usamos el valor generado
      entityType: finalEntityType,
      transport: _selectedProtocol!,
      attributes: [
        {
          "object_id": _attributeObjectIdController.text.trim(),
          "name": _attributeNameController.text.trim(),
          "type": _attributeTypeController.text.trim(),
        },
      ],
    );

    try {
      final FiwareService service = FiwareService();
      // Llamamos al método único
      await service.createDevice(payload);

      // Llamamos al diálogo de éxito y le pasamos los datos para la ESP32
      _showSuccessDialog(
        finalDeviceId,
        apiKey,
        _selectedProtocol!,
        finalEntityType,
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString().split(':').last}'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registrar Dispositivo IoT')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // --- SECCIÓN 1: IDENTIFICACIÓN FIWARE ---
              Text(
                'Identificación de Entidad',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const Divider(),

              // --- SELECTOR DE PROTOCOLO ---
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Protocolo de Transporte',
                ),
                value: _selectedProtocol,
                items: _protocols.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() => _selectedProtocol = newValue);
                },
                validator: (value) =>
                    value == null ? 'Seleccione un protocolo.' : null,
              ),
              const SizedBox(height: 15),

              // Campo Device ID
              TextFormField(
                controller: _deviceIdController,
                decoration: const InputDecoration(
                  labelText: 'Device ID (Identificador Único)',
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Este campo es requerido.' : null,
              ),

              // --- SELECTOR TIPO DE ENTIDAD ---
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Entity Type (Tipo de Dispositivo/Entidad)',
                ),
                value: _selectedEntityType,
                items: _entityTypes.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() => _selectedEntityType = newValue);
                },
                validator: (value) =>
                    value == null ? 'Seleccione el tipo de entidad.' : null,
              ),

              // 🚨 NOTA: Los campos Entity Name y Entity Type fueron eliminados/reemplazados
              // por la autogeneración y el Dropdown Button.
              const SizedBox(height: 30),

              // --- SECCIÓN 2: ATRIBUTO IOT AGENT ---
              Text(
                'Mapeo de Atributo (IoT Agent)',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const Divider(),
              TextFormField(
                controller: _attributeObjectIdController,
                decoration: const InputDecoration(
                  labelText:
                      'Object ID (Clave corta para datos entrantes, p. ej., t o h)',
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Este campo es requerido.' : null,
              ),
              TextFormField(
                controller: _attributeNameController,
                decoration: const InputDecoration(
                  labelText:
                      'Attribute Name (Nombre en Orion, p. ej., temperature)',
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Este campo es requerido.' : null,
              ),

              // --- SELECTOR DE TIPO DE ATRIBUTO ---
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Attribute Type (Tipo de dato NGSI)',
                ),
                value: _attributeTypeController.text.isEmpty
                    ? null
                    : _attributeTypeController.text,
                items: _attributeTypes.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    setState(() => _attributeTypeController.text = newValue);
                  }
                },
                validator: (value) => value == null || value.isEmpty
                    ? 'Seleccione el tipo de dato.'
                    : null,
              ),

              const SizedBox(height: 40),

              // Botón de Registro
              ElevatedButton.icon(
                onPressed: _isLoading ? null : _registerDevice,
                icon: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.cloud_upload),
                label: Text(
                  _isLoading ? 'Registrando...' : 'Registrar Dispositivo',
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
