import 'package:flutter/material.dart';
import 'package:ecosistema/services/fiware_service.dart';
// CAMBIO 1: Eliminamos EntityModel, ya no se usa para tarjetas
// import 'package:ecosistema/models/entity_model.dart';
// CAMBIO 2: Importamos el modelo correcto
import 'package:ecosistema/models/tarjeta_model.dart';
import '../widgets/custom_snack_bar.dart';
import 'dart:async'; // Para el uso de Future

// ====================================================
// --- 1. CLASE RFID CRUD VIEW (Gestión de Tarjetas) ---
// ====================================================

class RfidCrudView extends StatefulWidget {
  const RfidCrudView({super.key});

  @override
  State<RfidCrudView> createState() => _RfidCrudViewState();
}

class _RfidCrudViewState extends State<RfidCrudView> {
  final FiwareService _fiwareService = FiwareService();
  // CAMBIO 3: El Future ahora maneja List<TarjetaModel>
  Future<List<TarjetaModel>>? _cardsFuture;

  @override
  void initState() {
    super.initState();
    _loadCards();
  }

  void _loadCards() {
    setState(() {
      _cardsFuture = _fiwareService.getRfidCards();
    });
  }

  // Diálogo para Crear y Editar Tarjeta
  // CAMBIO 4: Acepta TarjetaModel como argumento
  void _showCardForm({TarjetaModel? card}) {
    final isEditing = card != null;
    final idController = TextEditingController(text: card?.id);
    // CAMBIO 5: Acceso directo a la propiedad 'estado'
    String? estadoSeleccionado = card?.estado;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            isEditing ? 'Editar Tarjeta RFID' : 'Crear Nueva Tarjeta',
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(
                  controller: idController,
                  decoration: const InputDecoration(
                    labelText: 'ID Tarjeta (Ej: F5A7B8C9)',
                  ),
                  readOnly: isEditing,
                ),
                const SizedBox(height: 15),
                // Selector de Estado
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Estado'),
                  value: estadoSeleccionado,
                  items: ['disponible', 'asignada', 'bloqueada'].map((
                    String value,
                  ) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value.toUpperCase()),
                    );
                  }).toList(),
                  onChanged: isEditing
                      ? (String? newValue) {
                          estadoSeleccionado = newValue;
                        }
                      : null,
                  style: isEditing ? null : const TextStyle(color: Colors.grey),
                ),
                if (!isEditing)
                  const Padding(
                    padding: EdgeInsets.only(top: 8.0),
                    child: Text(
                      'El estado por defecto al crear es "no_asignada".',
                      style: TextStyle(fontSize: 12, color: Colors.orange),
                    ),
                  ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              onPressed: () async {
                final rfidId = idController.text.trim().toUpperCase();

                if (rfidId.isEmpty) {
                  showSnackBar(
                    context,
                    'El ID de la tarjeta es requerido.',
                    isError: true,
                  );
                  return;
                }

                try {
                  if (isEditing) {
                    // CAMBIO 6: Acceso directo a card.estado
                    if (estadoSeleccionado == null ||
                        estadoSeleccionado == card.estado) {
                      showSnackBar(
                        context,
                        'No hay cambios para actualizar.',
                        isError: true,
                      );
                      return;
                    }
                    await _fiwareService.updateRfidCard(card.id, {
                      'estado': estadoSeleccionado,
                      // NOTA: Aquí se podría añadir la lógica para actualizar la fecha_entrega/baja si es necesario.
                    });
                    showSnackBar(context, 'Tarjeta $rfidId actualizada.');
                  } else {
                    // NOTA: Para resolver el error 500 (Data Truncated) que persiste
                    // es vital asegurarse de enviar TODAS las columnas que son NOT NULL
                    // y que las fechas se envíen como NULL o con formato correcto.
                    final payload = {
                      'id': rfidId,
                      'estado': estadoSeleccionado ?? 'disponible',
                      // AGREGAMOS CAMPOS NULOS PARA FECHAS, si la DB lo requiere:
                      'fecha_entrega': null,
                      'fecha_baja': null,
                    };
                    await _fiwareService.createRfidCard(payload);
                    showSnackBar(
                      context,
                      'Tarjeta $rfidId creada exitosamente.',
                    );
                  }
                  Navigator.of(context).pop();
                  _loadCards(); // Recargar la lista
                } catch (e) {
                  showSnackBar(
                    context,
                    e.toString().replaceAll('Exception: ', ''),
                    isError: true,
                  );
                }
              },
              child: Text(isEditing ? 'Guardar Cambios' : 'Crear Tarjeta'),
            ),
          ],
        );
      },
    );
  }

  // Función para confirmar la eliminación
  // CAMBIO 7: Acepta TarjetaModel como argumento
  Future<void> _confirmDeleteCard(TarjetaModel card) async {
    final bool? confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar Eliminación'),
        content: Text(
          '¿Está seguro de que desea eliminar la tarjeta ${card.id}? Esto también desvinculará a cualquier persona asociada.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Eliminar', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await _fiwareService.deleteRfidCard(card.id);
        showSnackBar(context, 'Tarjeta ${card.id} eliminada correctamente.');
        _loadCards(); // Recargar la lista
      } catch (e) {
        showSnackBar(
          context,
          e.toString().replaceAll('Exception: ', ''),
          isError: true,
        );
      }
    }
  }

  // Construye la tarjeta individual
  // CAMBIO 8: Acepta TarjetaModel como argumento
  Widget _buildCardTile(TarjetaModel card) {
    // CAMBIO 9: Acceso directo a la propiedad 'estado'
    final estado = card.estado;
    Color estadoColor;

    switch (estado) {
      case 'asignada':
        estadoColor = Colors.green;
        break;
      case 'perdida':
        estadoColor = Colors.red;
        break;
      case 'baja':
        estadoColor = Colors.grey;
        break;
      default: // no_asignada, etc.
        estadoColor = Colors.orange;
    }

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: estadoColor.withOpacity(0.1),
          child: Icon(Icons.credit_card, color: estadoColor),
        ),
        title: Text(
          card.id,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('Estado: ${estado.toUpperCase()}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, color: Colors.blue),
              onPressed: () => _showCardForm(card: card),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _confirmDeleteCard(card),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestión de Tarjetas RFID'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadCards),
        ],
      ),
      // CAMBIO 10: El FutureBuilder espera List<TarjetaModel>
      body: FutureBuilder<List<TarjetaModel>>(
        future: _cardsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  'Error al cargar tarjetas: ${snapshot.error}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text('No hay tarjetas RFID registradas.'),
            );
          }

          // Lista de Tarjetas
          return ListView.builder(
            padding: const EdgeInsets.all(10),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final card = snapshot.data![index];
              return _buildCardTile(card);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showCardForm(), // Llamar sin argumento para crear
        backgroundColor: Colors.green.shade600,
        child: const Icon(Icons.add_card, color: Colors.white),
      ),
    );
  }
}
