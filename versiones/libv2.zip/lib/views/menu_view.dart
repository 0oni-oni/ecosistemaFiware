// lib/views/menu_view.dart

import 'package:flutter/material.dart';
import 'widgets/app_drawer.dart'; // Mantener esta importación
import '/services/auth_service.dart'; // Importar el servicio de autenticación

// 1. Cambiamos a StatefulWidget para manejar el estado del usuario logueado
class MenuView extends StatefulWidget {
  const MenuView({super.key});

  @override
  State<MenuView> createState() => _MenuViewState();
}

class _MenuViewState extends State<MenuView> {
  String _username = 'Cargando...';

  @override
  void initState() {
    super.initState();
    _loadUsername();
  }

  // Carga el nombre del usuario para la bienvenida
  Future<void> _loadUsername() async {
    final name = await AuthService.getUsername();
    setState(() {
      _username = name ?? 'Usuario';
    });
  }

  // Maneja el cierre de sesión y redirige al login
  Future<void> _handleLogout() async {
    await AuthService().logout();
    if (mounted) {
      // Navega al login y elimina todas las rutas anteriores
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Opciones del menú principal para el GridView (se mantienen igual)
    final opciones = [
      {"titulo": "Ver Entidades", "icono": Icons.sensors, "ruta": "/devices"},
      {
        "titulo": "Registrar Dispositivo",
        "icono": Icons.add_box,
        "ruta": "/devices/new",
      },
      {
        "titulo": "Gestión de Tarjetas RFID",
        "icono": Icons.credit_card,
        "ruta": "/admin/rfid/cards",
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Panel Ecosistema FIWARE'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          // Mensaje de Bienvenida en la AppBar
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Center(
              child: Text(
                'Hola, $_username',
                style: const TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ),
        ],
      ),

      // 2. USO DEL WIDGET AppDrawer ACTUALIZADO
      drawer: AppDrawer(username: _username, onLogout: _handleLogout),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          childAspectRatio: 1.5,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: opciones.map((op) {
            return Card(
              elevation: 4,
              child: InkWell(
                onTap: () {
                  Navigator.pushNamed(context, op["ruta"] as String);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        op["icono"] as IconData,
                        size: 48,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        op["titulo"] as String,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
