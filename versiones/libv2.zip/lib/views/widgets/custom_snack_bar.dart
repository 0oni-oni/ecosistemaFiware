// Archivo: lib/widgets/custom_snack_bar.dart

import 'package:flutter/material.dart';

/// Función utilitaria para mostrar un SnackBar personalizado.
///
/// [context]: El BuildContext necesario para encontrar el ScaffoldMessenger.
/// [message]: El mensaje de texto que se mostrará.
/// [isError]: Si es verdadero, el SnackBar será de color rojo (error);
///            si es falso, será de color verde (éxito/información).
void showSnackBar(
  BuildContext context,
  String message, {
  bool isError = false,
}) {
  // Asegúrate de cerrar cualquier SnackBar anterior antes de mostrar el nuevo
  ScaffoldMessenger.of(context).hideCurrentSnackBar();

  final Color backgroundColor = isError
      ? Colors.red.shade700
      : Colors.green.shade700;
  final IconData icon = isError
      ? Icons.error_outline
      : Icons.check_circle_outline;

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          Icon(icon, color: Colors.white),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow
                  .ellipsis, // Para evitar que el texto sea muy largo
            ),
          ),
        ],
      ),
      backgroundColor: backgroundColor,
      duration: const Duration(seconds: 4),
      behavior: SnackBarBehavior.floating, // Hace que flote sobre el FAB
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
  );
}
