// Archivo: lib/widgets/app_drawer.dart (REFFACTORIZADO PARA CONTROL DE ROLES)

import 'package:flutter/material.dart';
import '/services/auth_service.dart'; // Importar para obtener el rol
// Necesario si usas RfidSimulatorView directamente, aunque es mejor usar rutas nombradas.

// 1. Convertimos a StatefulWidget para manejar la carga asíncrona del rol
class AppDrawer extends StatefulWidget {
  final String username;
  final VoidCallback onLogout;

  const AppDrawer({super.key, required this.username, required this.onLogout});

  @override
  State<AppDrawer> createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  String? _userRole; // Estado para almacenar el rol

  @override
  void initState() {
    super.initState();
    _loadUserRole();
  }

  // 2. Carga el rol del usuario al iniciar el widget
  void _loadUserRole() async {
    final role = await AuthService.getUserRole();
    if (mounted) {
      setState(() {
        _userRole = role;
      });
    }
  }

  // 3. Define y filtra las opciones de menú según el rol
  List<Map<String, dynamic>> _getMenuOptions() {
    final List<Map<String, dynamic>> opciones = [
      {"titulo": "Inicio", "icono": Icons.home, "ruta": "/"},
      {"titulo": "Dispositivos", "icono": Icons.sensors, "ruta": "/devices"},
      // Opción de simulador (visible para todos)
      {
        "titulo": "Simulador de Acceso (RFID)",
        "icono": Icons.screen_lock_portrait,
        "ruta": "/rfid/simulator",
      },
    ];

    // CONTROL DE ACCESO: Solo si el rol es 'root' o 'admin'
    if (_userRole == 'root' || _userRole == 'admin') {
      opciones.add({
        "titulo": "Gestión de Tarjetas RFID",
        "icono": Icons.credit_card,
        "ruta": "/admin/rfid/cards",
      });

      opciones.add({
        "titulo": "Gestión de Usuarios",
        "icono": Icons.people,
        "ruta": "/admin/users",
      });
    }

    return opciones;
  }

  @override
  Widget build(BuildContext context) {
    // Muestra el indicador de carga si el rol aún no se ha cargado
    if (_userRole == null) {
      return const Drawer(child: Center(child: CircularProgressIndicator()));
    }

    final opciones = _getMenuOptions();
    final roleDisplay = 'Rol: ${_userRole!}';

    return Drawer(
      child: Column(
        children: [
          // Encabezado del Drawer
          UserAccountsDrawerHeader(
            accountName: Text(
              widget.username,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            // Muestra el rol aquí
            accountEmail: Text(roleDisplay),
            currentAccountPicture: const CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: Colors.blue, size: 40),
            ),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary,
            ),
          ),

          // Opciones de la lista (filtradas)
          Expanded(
            child: ListView.builder(
              itemCount: opciones.length,
              itemBuilder: (context, index) {
                final op = opciones[index];
                return ListTile(
                  leading: Icon(op["icono"] as IconData),
                  title: Text(op["titulo"] as String),
                  onTap: () {
                    Navigator.pop(context);
                    // Navegación por nombre de ruta (para rutas definidas en main.dart)
                    Navigator.pushNamed(context, op["ruta"] as String);
                  },
                );
              },
            ),
          ),

          const Divider(),

          // Botón de Cerrar Sesión
          ListTile(
            leading: const Icon(Icons.exit_to_app, color: Colors.red),
            title: const Text('Cerrar Sesión'),
            onTap: () {
              Navigator.pop(context);
              widget.onLogout();
            },
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
