// lib/settings/app_settings.dart

// lib/settings/app_settings.dart (o similar)

class AppSettings {
  // Ahora usamos el dominio con HTTPS y SIN puerto (el puerto 443 es implícito)
  static const String API_BASE_URL = 'https://ecosistemafiware.com';

  // Si tienes rutas específicas para los servicios directos:
  static const String ORION_URL = '$API_BASE_URL/orion/v2';
  static const String HISTORICO_URL = '$API_BASE_URL/v2/quantum';
}
