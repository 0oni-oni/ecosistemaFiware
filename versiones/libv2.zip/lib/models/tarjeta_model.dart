// lib/models/tarjeta_model.dart

class TarjetaModel {
  final String id;
  final String estado;
  final String? fechaEntrega; // Puede ser null
  final String? fechaBaja; // Puede ser null

  final int? personaId;
  final String? personaNombre;

  TarjetaModel({
    required this.id,
    required this.estado,
    this.fechaEntrega,
    this.fechaBaja,
    this.personaId,
    this.personaNombre,
  });

  factory TarjetaModel.fromJson(Map<String, dynamic> json) {
    return TarjetaModel(
      id: json['id'] as String,
      estado: json['estado'] as String,
      fechaEntrega: json['fecha_entrega'] as String?,
      fechaBaja: json['fecha_baja'] as String?,
      personaId: json['persona_id'] as int?,
      personaNombre: json['persona_nombre'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'estado': estado,
      'fecha_entrega': fechaEntrega,
      'fecha_baja': fechaBaja,
      'persona_id': personaId,
      'persona_nombre': personaNombre,
    };
  }
}
