class UserModel {
  // Nota: id puede ser null para nuevos usuarios antes de ser creados
  final int? id;
  final String username;
  // password es opcional/transitorio, solo necesario para creación/actualización
  final String? password;
  final String role; // root, admin, user

  UserModel({
    this.id,
    required this.username,
    this.password,
    required this.role,
  });

  // Constructor para crear desde JSON (respuesta del API)
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as int?,
      username: json['username'] as String,
      // La contraseña nunca viene en la respuesta, por seguridad
      role: json['role'] as String,
    );
  }

  // Método para enviar a la API (solo para creación, ya que PUT usa Map)
  Map<String, dynamic> toJsonForCreation() {
    // Aseguramos que la contraseña exista para la creación
    if (password == null) {
      throw Exception("La contraseña es requerida para crear un usuario.");
    }
    return {'username': username, 'password': password!, 'role': role};
  }

  // Método simple para debug o logging
  @override
  String toString() {
    return 'User(id: $id, username: $username, role: $role)';
  }
}
