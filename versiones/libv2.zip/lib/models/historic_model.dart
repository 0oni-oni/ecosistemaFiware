// lib/models/historic_model.dart

import 'package:intl/intl.dart';

class HistoricModel {
  /// El tiempo de recepción de la base de datos (ej: 2025-12-08T...)
  final String recvTime;

  /// El valor del atributo (puede ser Number, String, etc.)
  final dynamic value;

  /// Nombre del atributo (p. ej., 'temperature', 'smoke')
  final String attributeName;

  HistoricModel({
    required this.recvTime,
    required this.value,
    required this.attributeName,
  });

  factory HistoricModel.fromJson(
    Map<String, dynamic> json,
    String attributeName,
  ) {
    // QuantumLeap/CrateDB estructura los datos de forma plana:
    // { "recvTime": "...", "temperature": 18.1, ... }
    return HistoricModel(
      recvTime: json['recvTime'] as String,
      // El valor se obtiene usando el nombre del atributo dinámico como clave
      value: json[attributeName],
      attributeName: attributeName,
    );
  }

  /// Getter para un formato de tiempo legible
  String get formattedTime {
    try {
      final dateTime = DateTime.parse(recvTime);
      // Formato más amigable para el usuario
      return DateFormat('dd/MM/yyyy HH:mm:ss').format(dateTime.toLocal());
    } catch (e) {
      return recvTime; // Retorna el crudo si falla el parsing
    }
  }
}
