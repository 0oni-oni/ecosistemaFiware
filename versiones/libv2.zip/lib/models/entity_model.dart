// lib/models/entity_model.dart

import 'package:intl/intl.dart';

class EntityModel {
  final String id;
  final String type;
  // Mapa dinámico que ahora almacenará los valores crudos de los atributos
  final Map<String, dynamic> attributes;

  EntityModel({required this.id, required this.type, required this.attributes});

  factory EntityModel.fromJson(Map<String, dynamic> json) {
    // 1. Mapa donde almacenaremos los atributos limpios (ej: "temperature": 20, "humedad": "dies")
    final Map<String, dynamic> cleanedAttributes = {};

    // 2. Iteramos sobre todas las claves del JSON de Orion
    json.forEach((key, value) {
      // 3. Solo procesamos si NO es 'id', NO es 'type' y es un Map (formato de atributo de Orion: {"value": X, "type": Y})
      if (key != 'id' && key != 'type' && value is Map) {
        // 4. Verificamos si contiene la clave 'value' (que es el dato real)
        if (value.containsKey('value')) {
          // 5. CLAVE: Extraemos solo el 'value' y lo guardamos con el nombre del atributo (key)
          cleanedAttributes[key] = value['value'];
        }
      }
    });

    return EntityModel(
      id: json['id'] as String,
      type: json['type'] as String,
      // Se asigna el mapa limpio
      attributes: cleanedAttributes,
    );
  }

  // --- GETTERS DE COMODIDAD (Ajustados para el mapa limpio) ---

  /// Obtiene el valor de un atributo (ej: entity.getAttributeValue('temperature') retorna 20)
  dynamic getAttributeValue(String attributeName) {
    // Lee directamente el valor del mapa limpio
    return attributes[attributeName];
  }

  /// Busca el primer atributo con valor que no sea TimeInstant.
  /// Esto es crucial para que el Historial sepa si debe consultar 'temperature' o 'humedad'.
  MapEntry<String, dynamic>? getMainAttribute() {
    try {
      // Buscamos la primera entrada en el mapa de atributos limpios que no sea TimeInstant
      return attributes.entries.firstWhere((e) => e.key != 'TimeInstant');
    } catch (e) {
      return null;
    }
  }

  /// Obtiene la última fecha/hora del atributo TimeInstant formateada.
  String getLastTimeInstant() {
    // TimeInstant ahora es un valor crudo (String) si existe en el mapa attributes
    final timeInstantValue = attributes['TimeInstant'];

    if (timeInstantValue is String) {
      try {
        final dateTime = DateTime.parse(timeInstantValue);
        return DateFormat('dd/MM HH:mm:ss').format(dateTime.toLocal());
      } catch (e) {
        return 'N/A';
      }
    }
    return 'N/A';
  }
}
