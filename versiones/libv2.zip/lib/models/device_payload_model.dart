// lib/models/device_payload_model.dart

class DevicePayloadModel {
  final String deviceId;
  final String entityName;
  final String entityType;
  final String transport; // <-- Campo para 'HTTP' o 'MQTT'
  final List<Map<String, String>> attributes;

  DevicePayloadModel({
    required this.deviceId,
    required this.entityName,
    required this.entityType,
    required this.transport,
    required this.attributes,
  });

  Map<String, dynamic> toJson() {
    // El formato JSON que tu middleware (FastAPI) espera recibir
    return {
      "device_id": deviceId,
      "entity_name": entityName,
      "entity_type": entityType,
      "transport": transport,
      "attributes": attributes,
    };
  }
}
