// lib/main.dart

import 'package:flutter/material.dart';
// IMPORTACIONES NECESARIAS PARA PROVIDER:
import 'package:provider/provider.dart';
import 'services/fiware_service.dart'; // Necesario para la lista de dispositivos y el historial

// IMPORTACIONES NECESARIAS DE RUTAS:
import 'services/auth_service.dart';
import 'views/login/login_view.dart';
import 'views/menu_view.dart';
import 'views/devices/device_list_view.dart';
import 'views/devices/device_form_view.dart';
import 'views/admin/user_management_view.dart';
import 'views/rfid/rfid_crud_view.dart';

void main() {
  runApp(
    Provider<FiwareService>(
      // Se crea una única instancia de FiwareService disponible para toda la aplicación
      create: (context) => FiwareService(),
      // La aplicación completa es el 'child' del Provider
      child: const EcosistemaApp(),
    ),
  );
}

// WRAPPER: Verifica el estado de autenticación al inicio
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: AuthService.isUserLoggedIn(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final bool isLoggedIn = snapshot.data ?? false;

        if (isLoggedIn) {
          return const MenuView();
        } else {
          return const LoginView();
        }
      },
    );
  }
}

// Punto de entrada de la aplicación.
class EcosistemaApp extends StatelessWidget {
  const EcosistemaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ecosistema FIWARE | SmartLab',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        fontFamily: 'Montserrat',
      ),

      initialRoute: '/auth_check',

      // DEFINICIÓN DE RUTAS
      routes: {
        '/auth_check': (context) => const AuthWrapper(),

        // Rutas Principales
        '/': (context) => const MenuView(),
        '/login': (context) => const LoginView(),

        // Rutas de Dispositivos (Entidades)
        '/devices': (context) => const DeviceListView(),
        '/devices/new': (context) => const DeviceFormView(),

        // Ruta de Administración de Usuarios
        '/admin/users': (context) => const UserManagementView(),

        '/admin/rfid/cards': (context) => const RfidCrudView(),
      },
    );
  }
}
