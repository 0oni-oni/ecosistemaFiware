// lib/services/auth_service.dart (CORREGIDO Y ADAPTADO)

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '/settings/app_settings.dart';

// Usamos FlutterSecureStorage para guardar el token de forma segura
const storage = FlutterSecureStorage();

class AuthService {
  // 💡 USAR LA URL BASE CONFIGURADA (https://ecosistemafiware.com)
  static const String _baseUrl = AppSettings.API_BASE_URL;

  // --- 1. LÓGICA DE LOGIN ---

  // Petición de LOGIN (Obtener el Token JWT)
  Future<bool> login(String username, String password) async {
    final loginUrl = Uri.parse('$_baseUrl/accesos/login');

    final response = await http.post(
      loginUrl,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'username=$username&password=$password',
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final token = data['access_token'];

      //  CAMBIO CRÍTICO 1: Capturar el rol del usuario de la respuesta del backend
      final role = data['user_role'] as String?;

      // 1. GUARDAR EL TOKEN
      await storage.write(key: 'jwt', value: token);
      // 2. GUARDAR EL NOMBRE DE USUARIO
      await storage.write(key: 'username', value: username);

      //  CAMBIO CRÍTICO 2: Guardar el rol en almacenamiento seguro
      if (role != null) {
        await storage.write(key: 'user_role', value: role);
      }

      return true;
    } else {
      return false;
    }
  }

  // --- 2. GESTIÓN DEL TOKEN Y SESIÓN ---

  static Future<Map<String, String>> getAuthHeaders() async {
    final token = await storage.read(key: 'jwt');
    var headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
    }

    return headers;
  }

  // RECUPERAR EL TOKEN (sin cambios)
  static Future<String?> getToken() async {
    return await storage.read(key: 'jwt');
  }

  // RECUPERAR EL NOMBRE DE USUARIO (sin cambios)
  static Future<String?> getUsername() async {
    return await storage.read(key: 'username');
  }

  //  CAMBIO CRÍTICO 3: NUEVO MÉTODO PARA RECUPERAR EL ROL
  static Future<String?> getUserRole() async {
    return await storage.read(key: 'user_role');
  }

  // VERIFICAR SI HAY UN TOKEN ACTIVO (sin cambios)
  static Future<bool> isUserLoggedIn() async {
    return await storage.containsKey(key: 'jwt');
  }

  // CERRAR SESIÓN (Logout)
  Future<void> logout() async {
    await storage.delete(key: 'jwt');
    await storage.delete(key: 'username');
    //  CAMBIO 4: Eliminar el rol al cerrar sesión
    await storage.delete(key: 'user_role');
  }
}
