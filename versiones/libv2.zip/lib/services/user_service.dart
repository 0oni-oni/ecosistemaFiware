// lib/services/user_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '/settings/app_settings.dart';
import '/models/user_model.dart';
import 'auth_service.dart'; // Para obtener el token y los headers

class UserService {
  // Usar la URL base de AppSettings y construir la URL del recurso
  static const String _baseUrl = AppSettings.API_BASE_URL;
  static const String _userUrl = '$_baseUrl/admin/users';
  // Etiqueta para debug
  static const String _tag = 'UserService';

  // --- CRUD 1: READ (Listar todos) ---
  Future<List<UserModel>> getUsers() async {
    // 🚀 CORRECCIÓN MENOR: Usar _userUrl directamente para consistencia
    final url = Uri.parse(_userUrl);
    try {
      final headers = await AuthService.getAuthHeaders();
      final response = await http.get(url, headers: headers);

      if (response.statusCode == 200) {
        final List<dynamic> jsonList = json.decode(response.body);
        return jsonList.map((json) => UserModel.fromJson(json)).toList();
      } else if (response.statusCode == 401) {
        throw Exception(
          'Sesión expirada o no válida. Por favor, vuelva a iniciar sesión.',
        );
      } else if (response.statusCode == 403) {
        throw Exception(
          'Acceso denegado. Solo Root/Admin puede acceder a la lista.',
        );
      } else {
        throw Exception(
          'Error ${response.statusCode} al cargar usuarios. Intente de nuevo.',
        );
      }
    } on http.ClientException catch (e) {
      debugPrint('$_tag - Error de red en getUsers: $e');
      throw Exception('Fallo la conexión con el servidor. Verifique su red.');
    } catch (e) {
      debugPrint('$_tag - Error en getUsers: $e');
      rethrow;
    }
  }

  // --- CRUD 2: CREATE (Crear nuevo) ---
  Future<UserModel> createUser(UserModel user) async {
    final url = Uri.parse(_userUrl);
    try {
      final headers = await AuthService.getAuthHeaders();
      final response = await http.post(
        url,
        headers: headers,
        body: json.encode(user.toJsonForCreation()),
      );

      if (response.statusCode == 201) {
        return UserModel.fromJson(json.decode(response.body));
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception('No autorizado. Verifique su sesión y permisos.');
      } else {
        final errorBody = json.decode(response.body);
        final detail =
            errorBody['detail']?.toString() ??
            'Error desconocido al crear usuario.';
        throw Exception('Fallo al crear usuario: $detail');
      }
    } on http.ClientException catch (e) {
      debugPrint('$_tag - Error de red en createUser: $e');
      throw Exception('Fallo la conexión con el servidor. Verifique su red.');
    } catch (e) {
      debugPrint('$_tag - Error en createUser: $e');
      rethrow;
    }
  }

  // --- CRUD 3: UPDATE (Actualizar) ---
  Future<UserModel> updateUser(
    String username,
    Map<String, dynamic> updateData,
  ) async {
    final url = Uri.parse('$_userUrl/$username');
    try {
      final headers = await AuthService.getAuthHeaders();
      final response = await http.put(
        url,
        headers: headers,
        body: json.encode(updateData),
      );

      if (response.statusCode == 200) {
        return UserModel.fromJson(json.decode(response.body));
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception('No autorizado. Verifique su sesión y permisos.');
      } else if (response.statusCode == 404) {
        throw Exception('Usuario no encontrado.');
      } else {
        final errorBody = json.decode(response.body);
        final detail =
            errorBody['detail']?.toString() ??
            'Error desconocido al actualizar usuario.';
        throw Exception('Fallo al actualizar usuario: $detail');
      }
    } on http.ClientException catch (e) {
      debugPrint('$_tag - Error de red en updateUser: $e');
      throw Exception('Fallo la conexión con el servidor. Verifique su red.');
    } catch (e) {
      debugPrint('$_tag - Error en updateUser: $e');
      rethrow;
    }
  }

  // --- CRUD 4: DELETE (Eliminar) ---
  Future<void> deleteUser(String username) async {
    final url = Uri.parse('$_userUrl/$username');
    try {
      final headers = await AuthService.getAuthHeaders();
      final response = await http.delete(url, headers: headers);

      if (response.statusCode == 204) {
        return; // Éxito
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception('No autorizado. Verifique su sesión y permisos.');
      } else if (response.statusCode == 404) {
        throw Exception('Usuario a eliminar no encontrado.');
      } else {
        final errorBody = json.decode(response.body);
        final detail =
            errorBody['detail']?.toString() ??
            'Error desconocido al eliminar usuario.';
        throw Exception('Fallo al eliminar usuario: $detail');
      }
    } on http.ClientException catch (e) {
      debugPrint('$_tag - Error de red en deleteUser: $e');
      throw Exception('Fallo la conexión con el servidor. Verifique su red.');
    } catch (e) {
      debugPrint('$_tag - Error en deleteUser: $e');
      rethrow;
    }
  }
}
