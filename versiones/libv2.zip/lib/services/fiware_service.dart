// lib/services/fiware_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_service.dart';
import '/models/device_payload_model.dart';
import '/models/entity_model.dart';
import '/models/historic_model.dart';
// IMPORTACIÓN CLAVE: Importamos el modelo de tarjeta
import '/models/tarjeta_model.dart';
import '/settings/app_settings.dart';
import 'dart:async'; // Aseguramos el manejo de Futures

class FiwareService {
  static const String _baseUrl = AppSettings.API_BASE_URL;

  // --- 1. GET /entidades --- (Mantenido)
  Future<List<EntityModel>> getEntities() async {
    final url = Uri.parse('$_baseUrl/entidades');
    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List<dynamic> jsonList = json.decode(response.body);
        return jsonList.map((json) => EntityModel.fromJson(json)).toList();
      } else {
        throw Exception(
          'Error (${response.statusCode}) al cargar entidades: ${response.body}',
        );
      }
    } catch (e) {
      throw Exception('Fallo la conexión o el parsing de entidades: $e');
    }
  }

  // --- 2. POST /dispositivos --- (Mantenido)
  Future<Map<String, dynamic>> createDevice(DevicePayloadModel payload) async {
    final url = Uri.parse('$_baseUrl/dispositivos');
    final headers = await AuthService.getAuthHeaders();

    try {
      final response = await http.post(
        url,
        headers: headers,
        body: json.encode(payload.toJson()),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        final errorBody = json.decode(response.body);
        final detail =
            errorBody['detail'] ??
            'Token inválido o expirado. Debe iniciar sesión.';
        throw Exception('Fallo al crear dispositivo (No autorizado): $detail');
      } else {
        final errorBody = json.decode(response.body);
        final detail = errorBody['detail'] ?? 'Error desconocido';
        throw Exception(
          'Fallo al crear dispositivo (${response.statusCode}): $detail',
        );
      }
    } catch (e) {
      throw Exception('Error de red al crear dispositivo: $e');
    }
  }

  // lib/services/fiware_service.dart

  // --- 3. GET /historico/{id}/{atributo} --- (CORREGIDO)
  Future<List<HistoricModel>> getHistoricData({
    // CLAVE: Añadir llaves {}
    required String entityId,
    required String attributeName, // CLAVE: Usar 'attributeName'
  }) async {
    final headers = await AuthService.getAuthHeaders();
    // CLAVE: Usar attributeName para la URL
    final url = Uri.parse('$_baseUrl/historico/$entityId/$attributeName');

    try {
      final response = await http.get(url, headers: headers);

      if (response.statusCode == 200) {
        final decodedBody = json.decode(response.body);

        if (decodedBody is Map<String, dynamic>) {
          List<String> index =
              (decodedBody['index'] as List<dynamic>?)
                  ?.whereType<String>()
                  .toList() ??
              [];
          List<dynamic> values = decodedBody['values'] as List<dynamic>? ?? [];

          if (index.isEmpty ||
              values.isEmpty ||
              index.length != values.length) {
            return [];
          }

          List<HistoricModel> historicList = [];
          for (int i = 0; i < index.length; i++) {
            historicList.add(
              HistoricModel(
                recvTime: index[i],
                value: values[i],
                attributeName:
                    attributeName, // CLAVE: Usar 'attributeName' aquí
              ),
            );
          }
          return historicList.reversed.toList();
        } else {
          throw Exception(
            'Estructura de datos histórica inesperada (no es un Mapa).',
          );
        }
      } // ... (rest of error handling)
      else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception('No autorizado. Tu sesión puede haber expirado.');
      } else {
        throw Exception(
          'Error (${response.statusCode}) al cargar histórico: ${response.body}',
        );
      }
    } catch (e) {
      throw Exception('Fallo la conexión o el parsing de histórico: $e');
    }
  }

  // --- 4. DELETE /dispositivos/{device_id} --- (Mantenido)
  Future<void> deleteDevice(String deviceId) async {
    final deleteUri = Uri.parse('$_baseUrl/dispositivos/$deviceId');
    final headers = await AuthService.getAuthHeaders();

    try {
      final response = await http.delete(deleteUri, headers: headers);

      if (response.statusCode == 204) {
        return;
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception(
          'No autorizado. Tu sesión no tiene permisos o ha expirado.',
        );
      } else {
        String errorDetail = 'Error desconocido al eliminar dispositivo.';
        try {
          final Map<String, dynamic> data = json.decode(response.body);
          errorDetail = data['detail'] ?? errorDetail;
        } catch (_) {
          // Ignorar si el cuerpo no es JSON (ej: un 500 simple)
        }
        throw Exception(
          'Fallo al eliminar dispositivo: $errorDetail (Status: ${response.statusCode})',
        );
      }
    } catch (e) {
      throw Exception('Error de red al eliminar dispositivo: $e');
    }
  }

  // --- 5. GET /accesos/validar/{rfid} --- (Mantenido)
  Future<Map<String, dynamic>> validateRfidAccess(String rfid) async {
    final url = Uri.parse('$_baseUrl/accesos/validar/$rfid');
    final headers = await AuthService.getAuthHeaders();

    try {
      final response = await http.get(url, headers: headers);

      final body = utf8.decode(response.bodyBytes);

      if (response.statusCode == 200) {
        return json.decode(body);
      } else if (response.statusCode == 403) {
        final errorBody = json.decode(body);
        final detail =
            errorBody['detail'] ?? 'Tarjeta RFID no autorizada o inactiva.';
        throw Exception(detail);
      } else if (response.statusCode == 401) {
        throw Exception(
          'Usuario no autenticado. Tu sesión expiró o no tienes permisos.',
        );
      } else {
        String errorDetail = 'Error desconocido';
        try {
          final errorBody = json.decode(body);
          errorDetail = errorBody['detail'] ?? errorDetail;
        } catch (_) {
          errorDetail = 'Error de servidor (Status ${response.statusCode})';
        }
        throw Exception('Fallo en el acceso: $errorDetail');
      }
    } catch (e) {
      rethrow;
    }
  }

  // =======================================================
  // --- 6. CRUD de Tarjetas RFID (/accesos/tarjetas) ---
  // =======================================================

  /// GET /accesos/tarjetas - Lista todas las tarjetas RFID. (Ruta Protegida)
  // CAMBIO: Retorna List<TarjetaModel> en lugar de List<EntityModel>
  Future<List<TarjetaModel>> getRfidCards() async {
    final url = Uri.parse('$_baseUrl/accesos/tarjetas');
    final headers = await AuthService.getAuthHeaders();

    try {
      final response = await http.get(url, headers: headers);

      if (response.statusCode == 200) {
        final List<dynamic> jsonList = json.decode(response.body);

        // CORRECCIÓN: Usamos el modelo TarjetaModel para mapear el JSON plano
        return jsonList.map((json) => TarjetaModel.fromJson(json)).toList();
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception(
          'Acceso denegado: No tienes permisos de administración.',
        );
      } else {
        throw Exception(
          'Error (${response.statusCode}) al cargar tarjetas: ${response.body}',
        );
      }
    } catch (e) {
      rethrow;
    }
  }

  /// POST /accesos/tarjetas - Crea una nueva tarjeta RFID. (Ruta Protegida)
  // CAMBIO: El payload debe venir del widget y debe coincidir con el modelo
  Future<Map<String, dynamic>> createRfidCard(
    Map<String, dynamic> payload,
  ) async {
    final url = Uri.parse('$_baseUrl/accesos/tarjetas');
    final headers = await AuthService.getAuthHeaders();
    headers['Content-Type'] = 'application/json';

    try {
      final response = await http.post(
        url,
        headers: headers,
        body: json.encode(payload),
      );

      final body = json.decode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return body;
      } else if (response.statusCode == 409) {
        throw Exception('El ID de tarjeta ya existe.');
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception(
          'No autorizado. Solo administradores pueden crear tarjetas.',
        );
      } else {
        final detail = body['detail'] ?? 'Error desconocido';
        throw Exception(
          // Si el 500 persiste, es muy probable que el payload NO esté bien formado (ej: datos nulos, formato de fecha, o Data Truncated)
          'Fallo al crear tarjeta (${response.statusCode}): $detail',
        );
      }
    } catch (e) {
      rethrow;
    }
  }

  /// PATCH /accesos/tarjetas/{id} - Actualiza una tarjeta RFID. (Mantenido)
  Future<void> updateRfidCard(
    String cardId,
    Map<String, dynamic> payload,
  ) async {
    final url = Uri.parse('$_baseUrl/accesos/tarjetas/$cardId');
    final headers = await AuthService.getAuthHeaders();
    headers['Content-Type'] = 'application/json';

    try {
      final response = await http.patch(
        url,
        headers: headers,
        body: json.encode(payload),
      );

      if (response.statusCode == 200) {
        return;
      } else if (response.statusCode == 404) {
        throw Exception('Tarjeta no encontrada.');
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception(
          'No autorizado. Solo administradores pueden actualizar.',
        );
      } else {
        final body = json.decode(response.body);
        final detail = body['detail'] ?? 'Error desconocido';
        throw Exception(
          'Fallo al actualizar tarjeta (${response.statusCode}): $detail',
        );
      }
    } catch (e) {
      rethrow;
    }
  }

  /// DELETE /accesos/tarjetas/{id} - Elimina una tarjeta RFID. (Mantenido)
  Future<void> deleteRfidCard(String cardId) async {
    final url = Uri.parse('$_baseUrl/accesos/tarjetas/$cardId');
    final headers = await AuthService.getAuthHeaders();

    try {
      final response = await http.delete(url, headers: headers);

      if (response.statusCode == 200) {
        return;
      } else if (response.statusCode == 404) {
        throw Exception('Tarjeta no encontrada.');
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        throw Exception('No autorizado. Solo administradores pueden eliminar.');
      } else {
        final body = json.decode(response.body);
        final detail = body['detail'] ?? 'Error desconocido';
        throw Exception(
          'Fallo al eliminar tarjeta (${response.statusCode}): $detail',
        );
      }
    } catch (e) {
      rethrow;
    }
  }
}
